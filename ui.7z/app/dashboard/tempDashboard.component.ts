import {Component} from 'angular2/core';
import {InfoDashlet} from './dashlet/infoDashlet.component';
import {Observable} from 'rxjs/Rx';

@Component({
    selector: 'temp-dashboard',
    templateUrl: '../tpl/dashboard/tempDashboard.component.html',
    directives: []
})
export class TempDashboard {

}