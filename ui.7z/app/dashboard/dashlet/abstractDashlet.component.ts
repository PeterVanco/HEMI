import {Component, Input, OnInit, OnDestroy, NgZone} from 'angular2/core';
import {Subscription} from 'rxjs/Rx';
import {HemiService} from '../../service/hemiService.service';
import {DataModel} from '../../service/data.model';

export abstract class AbstractDashlet<T> implements OnInit, OnDestroy {

	private handler: Subscription;

	constructor(protected _hemiService: HemiService) {

	}

	abstract handleData(data: T);

	abstract extractData(model: DataModel): T;

	ngOnInit() {
		this.handler = this._hemiService.getInfoObservable().subscribe(model => {
            //console.log(this.constructor.name + ": New data received");
			let data: T = this.extractData(model);
			this.handleData(data);
		});
	}

	ngOnDestroy() {
		this.handler.unsubscribe();
	}

}