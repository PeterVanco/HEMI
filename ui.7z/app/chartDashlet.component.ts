import {Component} from 'angular2/core';

@Component({
    selector: 'my-app',
    template: `This is chart dashlet`
})
export class ChartDashlet {}